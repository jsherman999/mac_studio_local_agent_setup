#!/usr/bin/env bash
# Phase 4: OpenCode as the *local worker* harness (local models only, no Anthropic login).
source "$(dirname "$0")/lib.sh"
need_macos
if ! have opencode; then
  log "Installing OpenCode"
  brew install sst/tap/opencode || curl -fsSL https://opencode.ai/install | bash
fi
mkdir -p "$HOME/.config/opencode"
DEST="$HOME/.config/opencode/opencode.json"
if [[ -f "$DEST" ]] && ! cmp -s "$DEST" "$REPO_ROOT/config/opencode.json"; then
  cp "$DEST" "$DEST.bak.$(date +%s)"; warn "Backed up existing $DEST"
fi
cp "$REPO_ROOT/config/opencode.json" "$DEST"
log "OpenCode configured: $(opencode --version 2>/dev/null || echo installed)"
log "Try: cd some-repo && opencode run 'list the top-level modules and what they do'"
