# shellcheck shell=bash
# Shared helpers for setup scripts.
set -euo pipefail
REPO_ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
CONF_DIR="$HOME/.config/local-agent"
log()  { printf '\033[1;34m==>\033[0m %s\n' "$*"; }
warn() { printf '\033[1;33m!!\033[0m %s\n' "$*" >&2; }
die()  { printf '\033[1;31mxx\033[0m %s\n' "$*" >&2; exit 1; }
need_macos() { [[ "$(uname -s)" == "Darwin" && "$(uname -m)" == "arm64" ]] || die "Run on Apple silicon macOS."; }
have() { command -v "$1" >/dev/null 2>&1; }
brew_shellenv() { [[ -x /opt/homebrew/bin/brew ]] && eval "$(/opt/homebrew/bin/brew shellenv)"; }
