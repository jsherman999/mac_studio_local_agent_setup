#!/usr/bin/env bash
# Phase 2: LM Studio headless server + model downloads (MLX builds).
source "$(dirname "$0")/lib.sh"
need_macos
LMS="$HOME/.lmstudio/bin/lms"
[[ -x "$LMS" ]] || die "lms CLI not found. Open LM Studio once, then: ~/.lmstudio/bin/lms bootstrap"
"$LMS" bootstrap >/dev/null 2>&1 || true

# Edit to taste. Check current best MLX builds in LM Studio's model browser first; these ids
# must match config/local-agent.env.example and config/opencode.json.
GENERAL=${GENERAL:-openai/gpt-oss-120b}   # ~60-65 GB, strong general reasoning, long context
CODER=${CODER:-qwen/qwen3-coder-30b}      # MoE, fast, tool-calling coder

for m in "$GENERAL" "$CODER"; do
  log "Downloading $m (MLX)"
  "$LMS" get "$m" --mlx -y || "$LMS" get "$m" -y
done

log "Starting API server on :1234"
"$LMS" server start --port 1234 || true

log "Loading models (context lengths sized to fit together in 128 GB; adjust if OOM)"
"$LMS" load "$GENERAL" --context-length 65536 -y || warn "load $GENERAL failed"
"$LMS" load "$CODER"   --context-length 65536 -y || warn "load $CODER failed"
"$LMS" ps || true

log "Install login agent for the server"
mkdir -p "$HOME/Library/LaunchAgents"
cp "$REPO_ROOT/config/launchd/com.local-agent.lmstudio-server.plist" "$HOME/Library/LaunchAgents/"
launchctl bootstrap "gui/$(id -u)" "$HOME/Library/LaunchAgents/com.local-agent.lmstudio-server.plist" 2>/dev/null || true

cat <<MSG
In LM Studio > Developer > Server settings, enable:
  - Just-in-Time model loading      (models load on first request)
  - Auto unload unused JIT models   (TTL e.g. 60 min)
  - Serve on local network: OFF     (unless you deliberately want LAN access)
Verify: curl -s localhost:1234/v1/models | jq '.data[].id'
MSG
